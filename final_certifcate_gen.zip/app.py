from random import randint
from time import strftime
from flask import Flask, render_template, flash,send_file, request,redirect, url_for
from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
import os,time
import pdfrw
import random
from datetime import timedelta
from flask import session, app

ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = 'SjdnUends821Jsdlkvxh391ksdODnejdDw'
@app.errorhandler(404)
def not_found(e):
  return "<h1>go to home page</h1>Computer Science - Yale U. <br> 404 <br>  "
@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=5)
@app.route('/termsandc')
def termsandconditions ():
    return render_template('termsandc.html')
@app.route('/')
def firstpage ():
    return render_template('index.html')
######################################
#download pdf
@app.route('/d')
def downloadFile ():
    #For windows you need to use drive name [ex: F:/Example.pdf]
    path = "invoice.pdf"
    print("///////////////////////8888888888888")
    return send_file(path, as_attachment=True)
######################################
@app.route('/Dpdf', methods=['GET', 'POST'])
def Dpdf():
    # render page, wait for the fn call
    form = ReusableForm(request.form)
    #print(form.errors)
    if request.method == 'POST':
        # surnames=request.form['surnames']
        print("////",xx)
        xx2=('This is to cerify that, {} {} have succesfully paricipated in the event - {} dedicated for {} branch, held at {} on {}. Thankyou'.format(xx['1'], xx['0'], xx['2'], xx['3'], xx['5'], xx['6']))
        xx21=('validation No:{}'.format(xx['8']))
        xx2 = str(xx2)
        xx21 = str(xx21)
        print("___",xx2,xx21)
        # xx1='aaaaaaaaaaaaaaaaaaaaaaaaa'
        INVOICE_TEMPLATE_PATH = 'ttt.pdf'
        INVOICE_OUTPUT_PATH = 'certficat.pdf'
        ANNOT_KEY = '/Annots'
        ANNOT_FIELD_KEY = '/T'
        ANNOT_VAL_KEY = '/V'
        ANNOT_RECT_KEY = '/Rect'
        SUBTYPE_KEY = '/Subtype'
        WIDGET_SUBTYPE_KEY = '/Widget'
        def write_fillable_pdf(input_pdf_path, output_pdf_path, data_dict):
            template_pdf = pdfrw.PdfReader(input_pdf_path)
            annotations = template_pdf.pages[0][ANNOT_KEY]
            for annotation in annotations:
                if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
                    if annotation[ANNOT_FIELD_KEY]:
                        key = annotation[ANNOT_FIELD_KEY][1:-1]
                        if key in data_dict.keys():
                            annotation.update(
                                pdfrw.PdfDict(V='{}'.format(data_dict[key]))
                            )
            pdfrw.PdfWriter().write(output_pdf_path, template_pdf)
            # return send_file(path, as_attachment=True)
            # path = "invoice.pdf"
            # return send_file(path, as_attachment=True)
            # return redirect('/')
        print("////>",xx)
        data_dict = {
            #'': '',
            '12': 'jone',
            'TextBox1': xx2,
            'TextBox2': xx21,
           'business_name_1': 'zzzzz',
           'name': 'oooo'
        }
        if __name__ == '__main__':
            write_fillable_pdf(INVOICE_TEMPLATE_PATH, INVOICE_OUTPUT_PATH, data_dict)
        time.sleep(2)
        # os.system("ls *.pdf")
        pathq = "certficat.pdf"
        print("-----------certficat send")
        # return 'bye'
        return send_file(pathq, as_attachment=True)
        print("--------------ending hear------------------")
#download pdf
#################################
class ReusableForm(Form):
    name = TextField('Name:', validators=[validators.required()])
    surnames = TextField('surnames:', validators=[validators.required()])
def get_time():
    time = strftime("%Y-%m-%dT%H:%M")
    return time
def write_to_disk(name, surnames, event,Branch,year,place,date,number,preHash):
    data = open('file.log', 'a')
    timestamp = get_time()
    data.write('DateStamp={}, Name={}, surnames={},event={},Branch={},year={},place={},date={},number={},preHash={} \n'.format(timestamp, name, surnames,event,Branch,year,place,date,number,preHash))
    data.close()
    print("---------write to disk",name, surnames, event,Branch,year,place,date,number,preHash)
@app.route("/form", methods=['GET', 'POST'])
def hello():
    form = ReusableForm(request.form)
    #print(form.errors)
    if request.method == 'POST':
        surnames=request.form['surnames']
        name=request.form['name']
        event=request.form['event']
        Branch=request.form['Branch']
        year=request.form['year']
        place=request.form['place']
        date=request.form['date']
        number=request.form['number']
        if form.validate():
            num=number[-4:]
            ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            chars=[]
            for i in range(3):
                chars.append(random.choice(ALPHABET))
            kk=("".join(chars))
            print(num+kk)
            preHash=(num+kk)


            print("-------hash>",preHash,"<<<<<<<<<")
            # write_to_disk(name, surnames, event,Branch,year,place,date,number)
            flash('Hello: {} {}'.format(surnames, name))
#################################################################
###############----------- DB ----------###########################
            data1 = open('hash.log', 'a')
            data1.write('{} \n'.format(preHash))
            data1.close()
#################################################################
            print(">>",name, surnames, event,Branch,year,place,date,number,preHash)
            # return name,surnames,event,Branch,year,place,date,number
            global xx
            xx= dict();
            xx = {'0': name, '1': surnames ,'2': event,'3': Branch, '4': year ,'5': place, '6': date ,'7': number,'8': preHash}

            write_to_disk(name, surnames, event,Branch,year,place,date,number,preHash)
            # return redirect(url_for('Dpdf'))
            return render_template('idownload.html')
        else:
            print("***f***")
            flash('Error: All Fields are Required !!')
    return render_template('form.html', form=form)
    # return redirect(url_for('Dpdf'))
@app.route("/db", methods=['GET', 'POST'])
def validate_this():
    form = ReusableForm(request.form)
    print("----***",form.errors)
    if request.method == 'POST':
        my_id=request.form['num']
        print("----my_id>>>",my_id)
        # if form.validate():
        my_id=str(my_id)
        print("---->>>",my_id)
        with open('hash.log') as f:
            if my_id in f.read():
                print("true")
                my_id=str(hash(my_id))
                my_id='succesfull Verified Uid:'+my_id
                flash(my_id)
            else:
                print("no")
                flash('invalid !!')
        # else:
        #     print("***f***")
        #     flash('Error: All Fields are Required !!')
    return render_template('validate.html', form=form)
if __name__ == "__main__":
    # app.run()
    global xx
    xx=dict()
    app.run(host = '0.0.0.0',port=5000,debug = True)
    # app.run(host = '0.0.0.0',port=5000,debug = True)
