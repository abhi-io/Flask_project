
please run test1.py with Flask application

linux commands to run aplication
-------------------------------
export FLASK_APP=test1
export FLASK_DEBUG=1
flask run


file structure
--------------
.
├── my_flask_app
│   ├── static
│   │   └── chest.png
│   ├── templates
│   │   ├── index1.html
│   │   └── t1.html
│   ├── test1.py
│   ├── test1.pyc
│   └── venv 
└── readME.txt









-Abhinand ns
