from random import randint
from time import strftime
from flask import Flask, render_template, flash, request
from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField


#certificte
# this is to cerify that MR-MS NAME have
#succesfully paricipated in the EVENT Name
# held at HOTEL on Date.
DEBUG = True
app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = 'SjdnUends821Jsdlkvxh391ksdODnejdDw'

class ReusableForm(Form):
    name = TextField('Name:', validators=[validators.required()])
    surnames = TextField('surnames:', validators=[validators.required()])

def get_time():
    time = strftime("%Y-%m-%dT%H:%M")
    return time

def write_to_disk(name, surnames, event,Branch,year,place,date,number):
    data = open('file.log', 'a')
    timestamp = get_time()
    data.write('DateStamp={}, Name={}, surnames={},event={},Branch={},year={},place={},date={},number={} \n'.format(timestamp, name, surnames,event,Branch,year,place,date,number))
    data.close()

@app.route("/", methods=['GET', 'POST'])
def hello():
    form = ReusableForm(request.form)

    #print(form.errors)
    if request.method == 'POST':
        surnames=request.form['surnames']
        name=request.form['name']
        event=request.form['event']
        Branch=request.form['Branch']
        year=request.form['year']
        place=request.form['place']
        date=request.form['date']
        number=request.form['number']

        if form.validate():
            write_to_disk(name, surnames, event,Branch,year,place,date,number)
            flash('Hello: {} {}'.format(name, event))
            print(">>",name, surnames, event,Branch,year,place,date,number)

        else:
            print("***f***")
            flash('Error: All Fields are Required !!')

    return render_template('index.html', form=form)

if __name__ == "__main__":
    app.run()
