
from random import randint
from time import strftime
from flask import Flask, render_template, flash,send_file, request,redirect, url_for
from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
import os,time
import pdfrw



#certificte
# this is to cerify that MR-MS NAME have
#succesfully paricipated in the EVENT Name
# held at HOTEL on Date.

app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = 'SjdnUends821Jsdlkvxh391ksdODnejdDw'

@app.errorhandler(404)
def not_found(e):
  return "<h1>go to home page</h1>Computer Science - Yale U. <br> 404 <br>  "
######################################
#download pdf
@app.route('/d')
def downloadFile ():

    #For windows you need to use drive name [ex: F:/Example.pdf]
    path = "invoice.pdf"
    print("///////////////////////8888888888888")
    return send_file(path, as_attachment=True)

######################################
@app.route('/Dpdf', methods=['GET', 'POST'])
def Dpdf():
    # render page, wait for the fn call
    form = ReusableForm(request.form)

    #print(form.errors)
    if request.method == 'POST':
        # surnames=request.form['surnames']
        print("////",xx)
        xx2=('this is to cerify that {} {} have succesfully paricipated in the {} dedicated for {} branch, held at {} on {}'.format(xx['1'], xx['0'], xx['2'], xx['3'], xx['5'], xx['6']))

        xx2 = str(xx2)
        print("___",xx2)
        # xx1='aaaaaaaaaaaaaaaaaaaaaaaaa'

        INVOICE_TEMPLATE_PATH = 'tt.pdf'
        INVOICE_OUTPUT_PATH = 'certficat.pdf'


        ANNOT_KEY = '/Annots'
        ANNOT_FIELD_KEY = '/T'
        ANNOT_VAL_KEY = '/V'
        ANNOT_RECT_KEY = '/Rect'
        SUBTYPE_KEY = '/Subtype'
        WIDGET_SUBTYPE_KEY = '/Widget'

        def write_fillable_pdf(input_pdf_path, output_pdf_path, data_dict):
            template_pdf = pdfrw.PdfReader(input_pdf_path)
            annotations = template_pdf.pages[0][ANNOT_KEY]
            for annotation in annotations:
                if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
                    if annotation[ANNOT_FIELD_KEY]:
                        key = annotation[ANNOT_FIELD_KEY][1:-1]
                        if key in data_dict.keys():
                            annotation.update(
                                pdfrw.PdfDict(V='{}'.format(data_dict[key]))
                            )
            pdfrw.PdfWriter().write(output_pdf_path, template_pdf)



            # return send_file(path, as_attachment=True)
            # path = "invoice.pdf"
            # return send_file(path, as_attachment=True)
            # return redirect('/')
        print("////>",xx)
        data_dict = {
            #'': '',
            '12': 'abhi',
            'TextBox1': xx2,
           'business_name_1': 'zzzzz',
           'name': 'oooo'
        }

        if __name__ == '__main__':
            write_fillable_pdf(INVOICE_TEMPLATE_PATH, INVOICE_OUTPUT_PATH, data_dict)
        print("888888888888888888888888888888888INVOICE_OUTPUT_PATH")
        time.sleep(2)
        # os.system("ls *.pdf")
        print("888888888888888888888888888888888INVOICE_OUTPUT_PATH")
        pathq = "certficat.pdf"
        print("///////////////////////8888888888888")
        # return 'bye'
        return send_file(pathq, as_attachment=True)
        print("--------------ending hear------------------")



#download pdf
#################################

class ReusableForm(Form):
    name = TextField('Name:', validators=[validators.required()])
    surnames = TextField('surnames:', validators=[validators.required()])

def get_time():
    time = strftime("%Y-%m-%dT%H:%M")
    return time

def write_to_disk(name, surnames, event,Branch,year,place,date,number):
    data = open('file.log', 'a')
    timestamp = get_time()
    data.write('DateStamp={}, Name={}, surnames={},event={},Branch={},year={},place={},date={},number={} \n'.format(timestamp, name, surnames,event,Branch,year,place,date,number))
    data.close()

@app.route("/", methods=['GET', 'POST'])
def hello():
    form = ReusableForm(request.form)

    #print(form.errors)
    if request.method == 'POST':
        surnames=request.form['surnames']
        name=request.form['name']
        event=request.form['event']
        Branch=request.form['Branch']
        year=request.form['year']
        place=request.form['place']
        date=request.form['date']
        number=request.form['number']

        if form.validate():
            write_to_disk(name, surnames, event,Branch,year,place,date,number)
            flash('Hello: {} {}'.format(name, event))
            print(">>",name, surnames, event,Branch,year,place,date,number)
            # return name,surnames,event,Branch,year,place,date,number
            xx= dict();
            xx = {'0': name, '1': surnames ,'2': event,'3': Branch, '4': year ,'5': place, '6': date ,'7': number}
            global xx
            # return redirect(url_for('Dpdf'))
            return render_template('idownload.html')


        else:
            print("***f***")
            flash('Error: All Fields are Required !!')

    return render_template('index.html', form=form)
    # return redirect(url_for('Dpdf'))

if __name__ == "__main__":
    # app.run()
    app.run(host = '0.0.0.0',port=5000,debug = True)
